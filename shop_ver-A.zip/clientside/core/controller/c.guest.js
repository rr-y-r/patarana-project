define([

], function(){
    function Ctrlguest($scope,serviceAjax,growl){

    }
    // set to global
    window.Ctrlguest = Ctrlguest;

    return Ctrlguest;
});