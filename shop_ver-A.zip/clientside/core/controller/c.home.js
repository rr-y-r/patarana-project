define([

], function(){
    function Ctrlhome($scope,$timeout,serviceAjax,localStorageService,growl){
       
        
    }

    // set to global
    window.Ctrlhome = Ctrlhome;

    return Ctrlhome;
});