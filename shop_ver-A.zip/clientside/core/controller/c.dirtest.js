define([

], function(){
    function Ctrldirtest($scope,serviceAjax,growl){

    }
    // set to global
    window.Ctrldirtest = Ctrldirtest;

    return Ctrldirtest;
});